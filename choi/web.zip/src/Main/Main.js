import React from 'react'
import { Switch, Route } from 'react-router-dom'
import Login from '../Login/Login'
import User_Group from '../User/User_Group'


const Main = () =>{
    return(
            <Switch>
                <Route exact path="/" component={Login}/>
                <Route path="/:userid" component={User_Group}/>
            </Switch>

    )
}

export default Main