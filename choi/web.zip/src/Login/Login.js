import React,{Component} from 'react'
import {Link, Route} from 'react-router-dom'
import GoogleLogin from 'react-google-login';
import './Login.css'
import GroupMain from "../GroupProject/GroupMain";


const responseGoogle = (response) => {
    console.log(response);
    this.props.router.match.url.push("/choi")
}

class Login extends Component{
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <switch>
                <Route exact path={this.props.match.url} render={()=>(
                    <div className="Login">
                        hi{this.props.match.url}
                        hi{this.props.match}
                        <h1>Login창입니다.</h1>
                        <GoogleLogin
                            clientId="1065031723084-4s4etvpbgndk46tn43ucurgmlsetrt7l.apps.googleusercontent.com"
                            buttonText="Login"
                            onSuccess={responseGoogle}
                            onFailure={responseGoogle}
                        />
                    </div>
                )}/>
                <Route path={`${this.props.match.url}/:userid`} component={GroupMain}/>
            </switch>
        )
    }
}

export default Login;