import React,{Component} from 'react'
import {Link, Route} from 'react-router-dom'
import GoogleLogin from 'react-google-login';
import './Login.css'
import GroupMain from "../GroupProject/GroupMain";


const responseGoogle = (response) => {
    console.log(response);
}

class Login extends Component{
    render() {
        return (
            <switch>
                <Route exact path={this.props.router} render={()=>(
                    <div className="Login">
                        hi{this.props.url}
                        <h1>Login창입니다.</h1>
                        <GoogleLogin
                            clientId="1065031723084-4s4etvpbgndk46tn43ucurgmlsetrt7l.apps.googleusercontent.com"
                            buttonText="Login"
                            onSuccess={this.onSignin}
                            onFailure={responseGoogle}
                        />
                    </div>
                )}/>
                <Route path={`${this.props.url}/:userid`} component={GroupMain}/>
            </switch>
        )
    }
}

export default Login;