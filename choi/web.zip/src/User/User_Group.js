import React from 'react'
import {Link} from "react-router-dom";
import {Switch,Route} from 'react-router-dom'
import GroupMain from '../GroupProject/GroupMain';
import './User_Group.css'
const User_Group = ({match}) =>{
    return(
        <Switch>
            <Route exact path={match.url} render={()=>(
                <div className="User_Group">
                    <h1>{match.params.userid}의 그룹</h1>
                    <h1>Group창입니다.</h1>
                    <h1>Group보여주기.</h1>
                    <h1>Group추가버튼.</h1>
                    <h1>{match.url}</h1>
                    <Link to="/choi/group1">group선택했다 치자</Link>
                </div>
            )}/>
            <Route path={`${match.url}/:groupid`} component={GroupMain}/>
        </Switch>
    )
}

export default User_Group