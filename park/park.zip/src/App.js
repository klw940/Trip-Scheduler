import React, { Component } from "react";
import { LoginForm, User_Group, GroupProject } from "./components";
import { BrowserRouter, Route, Switch } from "react-router-dom";
class App extends Component {
  render() {
    return (
      <BrowserRouter>
        <div className="App">
          <Route exact path="/" component={LoginForm} />
          <Switch>
            <Route path = "/:username/:groupid" component={GroupProject}/>
            <Route path="/:username" component={User_Group} />
          </Switch>
          {/* switch는 스위치안에서 선택 위에서 아래로 순서대로 확인
          exact는 정확히 해당경로만 
           */}
        </div>
      </BrowserRouter>
    );
  }
}

export default App;
