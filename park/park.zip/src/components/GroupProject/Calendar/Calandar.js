import React from 'react'

const Calandar = () =>{
    return(
        <div>
            <h1>Calandar창입니다.</h1>
        </div>
    )
}

export default Calandar;