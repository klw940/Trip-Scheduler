import React from 'react'

const Chat = (props) =>{
    return(
        <div className="Chat">
            <h1>{props.url}채팅창 입니다.</h1>
        </div>
    )
}

export default Chat;