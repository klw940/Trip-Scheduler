import PostData from './PostData/PostData';

export{
    PostData
}